import json
import os

from flask import Flask, jsonify, request, send_file

HERE = os.path.dirname(os.path.abspath(__file__))
STATE = os.path.join(HERE, "data", "state.json")
app = Flask(__name__)


def read():
    try:
        with open(STATE, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


@app.get("/")
def home():
    return send_file(os.path.join(HERE, "index.html"))


@app.get("/api/state/<path:key>")
def get_state(key):
    return jsonify(read().get(key, {}))


@app.post("/api/state/<path:key>")
def put_state(key):
    d = read()
    d[key] = request.get_json(silent=True) or {}
    os.makedirs(os.path.dirname(STATE), exist_ok=True)
    with open(STATE, "w", encoding="utf-8") as f:
        json.dump(d, f)
    return jsonify(ok=True)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=4000, debug=False)
