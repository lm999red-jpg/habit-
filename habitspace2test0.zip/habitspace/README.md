# HabitSpace

Black-and-white habit tracker. Runs on your computer at http://127.0.0.1:4000

## Set up (one time)
1. Install Python from python.org/downloads. On Windows, tick "Add python.exe to PATH".
2. Install Git from git-scm.com/downloads (keep the default choices).
3. Install VS Code from code.visualstudio.com.
4. Unzip habitspace.zip. In VS Code: File > Open Folder > choose the habitspace folder > "Yes, I trust the authors".
5. Click the Extensions icon (four squares, left bar), search "Python", install the one by Microsoft.

## Run it
1. Menu: Terminal > New Terminal.
2. Type `pip install -r requirements.txt` and press Enter (Mac: `pip3`).
3. Type `python app.py` and press Enter (Mac: `python3`. Windows: if that fails, `py app.py`).
4. Open http://127.0.0.1:4000 in your browser. Press Ctrl+C in the terminal to stop.
   (Or press F5 in VS Code to run it.)

Login: type an email and password, then press Create account (first time) or Log in (after that). Anyone can make their own account.
Use a made-up password, never your real Gmail one. Accounts and ticks are saved in data/state.json and in the browser.

## Put it on GitHub
1. On github.com click + > New repository. Name it `habitspace`. Click Create repository.
2. In the VS Code terminal, run these one line at a time (change YOURNAME, and use your own name and email on the first two):

```
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
git init
git add .
git commit -m "HabitSpace"
git branch -M main
git remote add origin https://github.com/YOURNAME/habitspace.git
git push -u origin main
```
3. A sign-in window opens on the first push. Sign in to GitHub.

## Free online copy with GitHub Pages
On your repository: Settings > Pages > Source: "Deploy from a branch" > Branch: main, folder: / (root) > Save.
After about a minute it is live at https://YOURNAME.github.io/habitspace/
(The online copy saves ticks in each visitor's own browser.)

## Change things without touching code
Click the menu button "Settings" in the side menu to change your habits, lessons, homework, school holidays, links and colours.

## Update the online copy after a change
Run these in the VS Code terminal:

```
git add .
git commit -m "Update"
git push
```

## Can't see your files in VS Code?
- A .zip must be unzipped first (right-click > Extract All). VS Code cannot look inside a zip.
- Use File > Open Folder and pick the unzipped habitspace folder. That window only lists folders; your files show in the Explorer list on the left (press Ctrl+Shift+E).
- A file saved somewhere else (like Downloads) will not show. Use File > Open File, or drag it into the VS Code window.
- A file downloaded on your phone is not on your PC. Email it to yourself or use Google Drive.

## On your phone
Open your GitHub Pages link in Chrome, tap the three dots, then Add to Home screen.
